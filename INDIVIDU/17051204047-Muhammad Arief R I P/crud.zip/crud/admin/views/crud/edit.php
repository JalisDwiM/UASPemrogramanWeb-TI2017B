<?php
require_once('koneksi.php');

   

if($_POST){
		

	$sql = "UPDATE mhs SET namamhs='".$_POST['namamhs']."', foto='".$_POST['foto']."', jk='".$_POST['userJk']."', prodi='".$_POST['prodi']."' WHERE id=".$_POST['id'];

	if ($koneksi->query($sql) === TRUE) {
	    echo "<script>
	alert('Data berhasil di update');
	window.location.href='index.php?page=crud/index';
	</script>";
	} else {
	    echo "Gagal: " . $koneksi->error;
	}

	$koneksi->close();
	
}else{
	$query = $koneksi->query("SELECT * FROM mhs WHERE id=".$_GET['id']);

	if($query->num_rows > 0){
		$data = mysqli_fetch_object($query);
	}else{
		echo "data tidak tersedia";
		die();
	}
?>
<div class="row">
	<div class="col-lg-6">
		<form action="upload.php" method="POST" enctype="multipart/form-data">
			<input type="hidden" name="id" value="<?= $data->id ?>">
			<div class="form-group">
				<label>Nama Lengkap</label>
				<input type="text" value="<?= $data->namamhs ?>" placeholder="Nama" class="form-control" name="namamhs">
			</div>
			<div class="form-group">
							<label>User image <span class="text-danger">*</span></label>
							<input type="file" name="file" id="foto" maxlength="12" class="form-control" value="<?= $data->foto ?>" placeholder="foto" required>
						</div>
			<div class="form-group">
							<label>User jenis kelamin <span class="text-danger">*</span></label>
							<select name="userJk" id="userJk" class="form-control" required>
								<option class="disable selected">pilih jenis kelamin</option>
								<option value="Laki-laki">Laki - laki</option>
								<option value="Perempuan">Perempuan</option>
							</select>
						</div>
			<div class="form-group">
							<label>Prodi <span class="text-danger">*</span></label>
							<select name="prodi" id="prodi" class="form-control" required>
								<option class="disable selected">pilih prodi</option>
								<option value="S1 Teknik Informatika">S1 Teknik Informatika</option>
								<option value="Sistem Informasi">S1 Sistem Informasi</option>
								<option value="S1 PTI">S1 PTI</option>
								<option value="D3 Manajemen Informatika">D3 Manajemen Informatika</option>
							</select>
						</div>
			<input type="submit" class="btn btn-primary btn-sm" name="Update" value="submit"/>
		</form>
	</div>
</div>
<?php
}
mysqli_close($koneksi);
?>