-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2019 at 07:32 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `username`, `password`) VALUES
(1, 'Arief Rahman', 'admin', '079fcac7902d9fb41b269ada64a932a0');

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `tempat_lahir` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `pekerjaan` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `nama`, `tanggal_lahir`, `tempat_lahir`, `status`, `pekerjaan`) VALUES
(2, 'Arief Rahman', '1998-11-29', 'Tulungagung', 'Belum Menikah', 'Mahasiswa'),
(3, 'Ridho Wahyudi', '1999-11-11', 'Banyuwangi', 'Menikah', 'Mahasiswa'),
(4, 'Mark Zuckerberg', '1994-11-12', 'Jakarta', 'Menikah', 'CEO'),
(5, 'Bill Gates', '1992-12-21', 'Jakarta', 'Menikah', 'CEO'),
(6, 'Adi Permana', '1990-05-11', 'Bali', 'Belum Menikah', 'Mahasiswa'),
(7, 'Dandy Muzakky', '1984-02-23', 'Surabaya', 'Belum Menikah', 'Mahasiswa'),
(8, 'Bisma Widyanto', '1963-01-24', 'Surabaya', 'Menikah', 'Wiraswasta'),
(9, 'Aldo Saputra', '1968-11-15', 'Surabaya', 'Menikah', 'Wirausaha'),
(10, 'Reza Oktovian', '1969-11-05', 'Surabaya', 'Menikah', 'TNI'),
(11, 'Rizaldi Ronald', '1988-11-03', 'Surabaya', 'Menikah', 'POLISI');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
