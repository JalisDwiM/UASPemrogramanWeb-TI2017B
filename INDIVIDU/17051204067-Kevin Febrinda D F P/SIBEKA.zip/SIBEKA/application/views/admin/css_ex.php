<!-- /**
 * @Author: Moch Faizal Ansyori
 * @Date:   2017-06-11 22:03:49
 * @Last Modified by:   Moch Faizal Ansyori
 * @Last Modified time: 2017-06-13 20:55:29
 */
 -->

 <link href="<?php echo base_url(''); ?>UI/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
 <link href="<?php echo base_url(''); ?>UI/assets/preload/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/css/style-default.css" rel="stylesheet" id="style_color" />
   <link href="<?php echo base_url(''); ?>UI/assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
   <link href="<?php echo base_url(''); ?>UI/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
	<link href="<?php echo base_url(''); ?>UI/sweet/sweetalert2.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/chosen-bootstrap/chosen/chosen.css" />

    <link href="<?php echo base_url(''); ?>UI/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
  
    <link href="<?php echo base_url(''); ?>UI/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/uniform/css/uniform.default.css" />
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/jquery-tags-input/jquery.tagsinput.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/clockface/css/clockface.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" href="<?php echo base_url(''); ?>UI/assets/bootstrap-toggle-buttons/static/stylesheets/bootstrap-toggle-buttons.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(''); ?>UI/assets/bootstrap-daterangepicker/daterangepicker.css" />
