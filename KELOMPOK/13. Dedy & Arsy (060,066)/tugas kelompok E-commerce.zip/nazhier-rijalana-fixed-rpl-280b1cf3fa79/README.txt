# My project's README
Cara instalasi Project 

1.pastikan sudah terinstall python 
2.install pip 
3.lakukan perintah sudo pip install -r requirement.txt
4. selesai, export database rpl1.sql ke mysql 
5. lalu rubah di settings/local.py,productions.py dan base.py di user pass dan nama database sesuai namanya 
6. lakukan perintah python manage.py migrate
8. jika sudah lakukan perintah python manage.py runserver 8080


