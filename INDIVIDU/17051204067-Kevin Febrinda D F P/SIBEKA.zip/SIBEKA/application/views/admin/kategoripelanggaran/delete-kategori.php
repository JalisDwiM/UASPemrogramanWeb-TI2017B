<!-- /**
 * @Author: Moch Faizal Ansyori
 * @Date:   2017-06-13 14:23:14
 * @Last Modified by:   Moch Faizal Ansyori
 * @Last Modified time: 2017-06-13 15:13:54
 */
 -->
 <!-- /**
 * @Author: Moch Faizal Ansyori
 * @Date:   2017-06-12 20:26:50
 * @Last Modified by:   Moch Faizal Ansyori
 * @Last Modified time: 2017-06-13 07:21:51
 */
 -->
<!-- Modal -->
<form class="cmxform form-horizontal" id="commentForm" method="post" action="<?php echo site_url('Kategoripelanggaran/delete'); ?>">
<div id="delete" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="color: white;background-color:#F13F3F">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
         <!-- BEGIN FORM-->
            <div class="control-group ">
                <label for="firstname" class="control-label">Nama Kategori</label>
                <div class="controls">
                    <label class="control-label" style="font-weight: bold;">: <?php echo $row['nama_kategori_kategori_pelanggaran']; ?></label>
                    <input type="hidden" value="<?php echo $row['id_kategori_pelanggaran']; ?>" name="id_">
                </div>
            </div>
        <!-- END FORM-->
      </div>
      <div class="modal-footer">
      	<button class="btn btn-danger" type="submit"><i class="icon-trash"></i> Hapus</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</form>