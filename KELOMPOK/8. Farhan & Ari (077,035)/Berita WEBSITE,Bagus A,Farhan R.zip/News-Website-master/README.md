# News-Website
This is a a news webiste, which provides news headlines from various news providers in world.
The app uses web API provided by newsapi.org. 
