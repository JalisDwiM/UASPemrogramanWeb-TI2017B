<?php
require_once('koneksi.php');
if($_POST){

	$sql = "UPDATE data SET nama='".$_POST['nama']."', tanggal_lahir='".$_POST['tanggal_lahir']."', tempat_lahir='".$_POST['tempat_lahir']."', status='".$_POST['status']."', pekerjaan='".$_POST['pekerjaan']."' WHERE id=".$_POST['id'];

	if ($koneksi->query($sql) === TRUE) {
	    echo "<script>
	alert('Data berhasil di update');
	window.location.href='index.php?page=crud/index';
	</script>";
	} else {
	    echo "Gagal: " . $koneksi->error;
	}

	$koneksi->close();
	
}else{
	$query = $koneksi->query("SELECT * FROM data WHERE id=".$_GET['id']);

	if($query->num_rows > 0){
		$data = mysqli_fetch_object($query);
	}else{
		echo "data tidak tersedia";
		die();
	}
?>
<div class="row">
	<div class="col-lg-6">
		<form action="" method="POST">
			<input type="hidden" name="id" value="<?= $data->id ?>">
			<div class="form-group">
				<label>Nama Lengkap</label>
				<input type="text" value="<?= $data->nama ?>" placeholder="Nama" class="form-control" name="nama">
			</div>
			<div class="form-group">
				<label>Tanggal Lahir</label>
				<input type="text" value="<?= $data->tanggal_lahir ?>" placeholder="Tahun-Bulan-Tanggal" class="form-control" name="tanggal_lahir">
			</div>
			<div class="form-group">
				<label>Tempat Lahir</label>
				<input type="text" value="<?= $data->tempat_lahir ?>" placeholder="Tempat Lahir" class="form-control" name="tempat_lahir">
			</div>
			<div class="form-group">
			<label>Status?</label>
				<select name="status">
					<option value="">Pilih...</option>
					<option value="Menikah">Menikah</option>
					<option value="Belum Menikah">Belum Menikah</option>
					<option value="Cerai Hidup">Cerai Hidup</option>
					<option value="Cerai Mati">Cerai Mati</option>
				</select>
			</div>
			<div class="form-group">
				<label>Pekerjaan</label>
				<input type="text" value="<?= $data->pekerjaan ?>" placeholder="Pekerjaan" class="form-control" name="pekerjaan">
			</div>
			<input type="submit" class="btn btn-primary btn-sm" name="Update" value="Update">
		</form>
	</div>
</div>
<?php
}
mysqli_close($koneksi);
?>