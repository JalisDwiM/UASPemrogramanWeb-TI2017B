<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <h1 class="h3 mb-4 text-gray-800 text-center">Headmaster Election!</h1>
    <?php foreach ($vote as $v) : ?>
        <div class="row mt-4">
            <div class="col-md3">
                <img src="<?= base_url('assets/img/vote/') . $v['image']; ?>" alt="" width="100px" class="rounded-circle">
            </div>
            <div class="col-md-3">
                <h5><?= $v['name']; ?> (<?= $v['count']; ?> vote)</h5>
            </div>
            <div class="col-md-6">

                <div class="progress">
                    <div class="progress-bar <?php if ($v['id'] == 1) {
                                                    echo "bg-success";
                                                } else {
                                                    echo "bg-danger";
                                                } ?>" role="progressbar" style="width: <?= $v['count'] / $total * 100; ?>%;" aria-valuenow="<?= $v['count'] / $total * 100; ?>" aria-valuemin="0" aria-valuemax="100"><?= $v['count'] / $total * 100; ?> %</div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    <h2 class="mt-2 text-center">Voting result! (<?= $total; ?> Total voted)</h2>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->