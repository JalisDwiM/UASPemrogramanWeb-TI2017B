<!--
COPYRIGHT : M. Arief Rahman I.P
CREATED : 00.35 27/05/2019
NIM : 17051204047
-->
<?php
require_once('koneksi.php');

$query = "SELECT * FROM mhs,fakultas";
$urlcrud = "index.php?page=crud/";
?>
<div class="row">
	<div class="col-lg-12">
	<form name="formcari" method="post" action="search_exe.php">
<tr> <td>  Cari </td>
<td> <input type="text" name="name"> </td>
</tr>
<td></td>
<td> <input type="SUBMIT" name="SUBMIT" id="SUBMIT" value="search" > </td>
</form>
		<table class="table table-hover table-bordered" style="margin-top: 10px">
			<tr class="success">
				<th width="50px">No</th>
				<th>Foto</th>
				<th>Nama</th>
				<th>JK</th>
				<th>Prodi</th>
				<th>Fakultas</th>
			</tr>
			<?php
			if($data=mysqli_query($koneksi,$query)){
				$a=1;
				while($obj=mysqli_fetch_object($data)){
					?>
					<tr>
						<td><?= $a ?></td>
						<td><img src="img/<?= $obj->foto ?>"width="130" height="150"></td>
						<td><?= $obj->namamhs ?></td>
						<td><?= $obj->jk ?></td>
						<td><?= $obj->prodi ?></td>
						<td><?= $obj->fakultas ?></td>
						</td>
					</tr>
					<?php
					$a++;
				}
				mysqli_free_result($data);
			}
			?>
		</table>
	</div>
</div>
<?php
mysqli_close($koneksi);
?>