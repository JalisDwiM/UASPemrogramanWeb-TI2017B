<?php
require_once('koneksi.php');
if($_POST){
	try {
		$sql = "INSERT INTO data (nama,tanggal_lahir,tempat_lahir,status,pekerjaan) VALUES ('".$_POST['nama']."','".$_POST['tanggal_lahir']."','".$_POST['tempat_lahir']."','".$_POST['status']."','".$_POST['pekerjaan']."')";
		if(!$koneksi->query($sql)){
			echo $koneksi->error;
			die();
		}

	} catch (Exception $e) {
		echo $e;
		die();
	}
	  echo "<script>
	alert('Data berhasil di simpan');
	window.location.href='index.php?page=crud/index';
	</script>";
}
?>
<div class="row">
	<div class="col-lg-6">
		<form action="" method="POST">
			<div class="form-group">
				<label>Nama Lengkap</label>
				<input type="text" value="" placeholder="Nama" class="form-control" name="nama">
			</div>
			<div class="form-group">
				<label>Tanggal Lahir</label>
				<input type="text" value="" placeholder="Tahun-Bulan-Tanggal" class="form-control" name="tanggal_lahir">
			</div>
			<div class="form-group">
				<label>Tempat Lahir</label>
				<input type="text" value="" placeholder="Tempat Lahir" class="form-control" name="tempat_lahir">
			</div>
			<div class="form-group">
			<label>Status?</label>
				<select name="status">
					<option value="">Pilih...</option>
					<option value="Menikah">Menikah</option>
					<option value="Belum Menikah">Belum Menikah</option>
					<option value="Cerai Hidup">Cerai Hidup</option>
					<option value="Cerai Mati">Cerai Mati</option>
				</select>
			</div>
			<div class="form-group">
				<label>Pekerjaan</label>
				<input type="text" value="" placeholder="Pekerjaan" class="form-control" name="pekerjaan">
			</div>
			<input type="submit" class="btn btn-primary btn-sm" name="create" value="Create">
		</form>
	</div>
</div>