<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <?= $this->session->flashdata('message'); ?>
    <h2>Please vote the Headmaster</h2>
    <?php foreach ($headmaster as $hm) : ?>
        <div class="card mt-3 float-left mr-5" style="width: 18rem;">
            <img src="<?= base_url('assets/img/vote/') . $hm['image'] ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?= $hm['name'] ?></h5>
                <p class="card-text"><?= $hm['nip'] ?></p>
                <a href="<?= base_url('voting/vote/') . $hm['id']; ?>" class="btn btn-success">Vote</a>
            </div>
        </div>
    <?php endforeach; ?>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->