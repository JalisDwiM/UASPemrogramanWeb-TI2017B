<?php
$koneksi = new mysqli('localhost', 'root', '','crud');

if ($koneksi->connect_error) {
    die("Koneksi Gagal: " . $koneksi->connect_error);
} 
?>