<!--
COPYRIGHT : M. Arief Rahman I.P
CREATED : 00.35 27/05/2019
NIM : 17051204047
-->
<?php
require_once('koneksi.php');
if($_POST){
	$ekstensi_diperbolehkan	= array('png','jpg');
			$nama = $_FILES['file']['name'];
			$x = explode('.', $nama);
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['file']['size'];
			$file_tmp = $_FILES['file']['tmp_name'];	
 
			if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
				if($ukuran < 99999999999999){			
					move_uploaded_file($file_tmp, 'img/'.$nama);
					$query = mysql_query("INSERT INTO mhs VALUES(NULL, '$nama')");
					if($query){
						echo 'FILE BERHASIL DI UPLOAD';
					}else{
						echo 'GAGAL MENGUPLOAD GAMBAR';
					}
				}else{
					echo 'UKURAN FILE TERLALU BESAR';
				}
			}else{
				echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
			}
	try {
		$sql = "INSERT INTO mhs (id,nim,namamhs,jk,tgllahir,alamat,kota,email,foto,telp,prodi) VALUES ('','".$_POST['nim']."','".$_POST['namamhs']."','".$_POST['jk']."','".$_POST['tgllahir']."','".$_POST['alamat']."','".$_POST['kota']."','".$_POST['email']."','".$_POST['foto']."','".$_POST['telp']."','".$_POST['prodi']."')";
		if(!$koneksi->query($sql)){
			echo $koneksi->error;
			die();
		}

	} catch (Exception $e) {
		echo $e;
		die();
	}
	  echo "<script>
	alert('Data berhasil di simpan');
	window.location.href='index.php?page=crud/index';
	</script>";
}
?>
<div class="row">
	<div class="col-lg-6">
		<form action="views/crud/make.php" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label>NIM</label>
				<input type="text" value="" placeholder="17051204047" class="form-control" name="nim">
			</div>
			<div class="form-group">
				<label>Nama Lengkap</label>
				<input type="text" value="" placeholder="Nama" class="form-control" name="namamhs">
			</div>
			<div class="form-group">
							<label>User jenis kelamin <span class="text-danger">*</span></label>
							<select name="userJk" id="userJk" class="form-control" required>
								<option class="disable selected">pilih jenis kelamin</option>
								<option value="Laki-laki">Laki - laki</option>
								<option value="Perempuan">Perempuan</option>
							</select>
						</div>
			<div class="form-group">
							<label>Prodi <span class="text-danger">*</span></label>
							<select name="prodi" id="prodi" class="form-control" required>
								<option class="disable selected">pilih prodi</option>
								<option value="S1 Teknik Informatika">S1 Teknik Informatika</option>
								<option value="Sistem Informasi">S1 Sistem Informasi</option>
								<option value="S1 PTI">S1 PTI</option>
								<option value="D3 Manajemen Informatika">D3 Manajemen Informatika</option>
							</select>
						</div>
						<div class="form-group">
				<label>Tanggal Lahir</label>
				<input type="date" value="" placeholder="Tanggal" class="form-control" name="tgllahir">
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<input type="text" value="" placeholder="Alamat" class="form-control" name="alamat">
			</div>
			<div class="form-group">
				<label>Kota</label>
				<input type="text" value="" placeholder="Kota" class="form-control" name="kota">
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="email" value="" placeholder="arief0039@gmail.com" class="form-control" name="email">
			</div>
			<div class="form-group">
							<label>User image <span class="text-danger">*</span></label>
							<input type="file" name="file" id="file" maxlength="12" class="form-control" value="<?= $data->foto ?>" placeholder="foto" required>
						</div>
			<div class="form-group">
				<label>No Telp</label>
				<input type="text" value="" placeholder="arief0039@gmail.com" class="form-control" name="telp">
			</div>
			<input type="submit" class="btn btn-primary btn-sm" name="Update" value="submit">
		</form>
	</div>
</div>