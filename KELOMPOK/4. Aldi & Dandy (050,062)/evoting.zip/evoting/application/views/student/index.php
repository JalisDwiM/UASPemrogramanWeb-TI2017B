<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <h2>this panel only for student!</h2>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->