<!--
COPYRIGHT : M. Arief Rahman I.P
CREATED : 00.35 27/05/2019
NIM : 17051204047
-->
<?php
$koneksi = new mysqli('localhost', 'root', '','crud');

if ($koneksi->connect_error) {
    die("Koneksi Gagal: " . $koneksi->connect_error);
} 
?>