<!--
COPYRIGHT : M. Arief Rahman I.P
CREATED : 00.35 27/05/2019
NIM : 17051204047
-->
<?php
include "pencarian.php";
$name= $_POST['name']; //get the nama value from form
$query = "SELECT * FROM fakultas,mhs WHERE namamhs like '%$name%'";
$result = mysql_query($query); //execute the query $q
$urlcrud = "index.php?page=crud/";
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Data Warga RT 05</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

   </head>

  <body>

    <!-- Static navbar -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Warga RT 05</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php?page=crud/index">Data Warga</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


    <div class="container">

     <div class="row">
	<div class="col-lg-12">
	<a href="<?= $urlcrud.'create' ?>" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-plus"></span> Tambah</a><br>
	<br><form name="formcari" method="post" action="search_exe.php">
<tr> <td>  Cari </td>
<td> <input type="text" name="name"> </td>
</tr>
<td></td>
<td> <input type="SUBMIT" name="SUBMIT" id="SUBMIT" value="search" > </td>
</form>
		<table class="table table-hover table-bordered" style="margin-top: 10px">
			<tr class="success">
				<th width="50px">No</th>
				<th>Foto</th>
				<th>Nama</th>
				<th>JK</th>
				<th>Prodi</th>
				<th>Fakultas</th>
				<th style="text-align: center;">Actions</th>
			</tr>
			<?php
			if($result=mysql_query($query)){
				$a=1;
			while ($obj=mysql_fetch_object($result)) {  
?>
			<tr>
						<td><?= $a ?></td>
						<td><img src="img/<?= $obj->foto ?>"width="130" height="150"></td>
						<td><?= $obj->namamhs ?></td>
						<td><?= $obj->jk ?></td>
						<td><?= $obj->prodi ?></td>
						<td><?= $obj->fakultas ?></td>
						<td style="text-align: center;">
						<a onclick="return confirm('Apakah yakin data akan di hapus?')" href="<?= $urlcrud.'hapus&id='.$obj->id ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span></a>
						<a href="<?= $urlcrud.'edit&id='.$obj->id ?>" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-edit"></span></a>
						</td>
					</tr>
					<?php
					$a++;
				}
				mysql_free_result($result);
			}
			?>
		</table>
							</tr>
	</div>
</div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    
  </body>

