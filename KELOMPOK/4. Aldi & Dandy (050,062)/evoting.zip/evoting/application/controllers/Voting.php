<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Voting extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Voting';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['headmaster'] = $this->db->get('headmaster')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('voting/index', $data);
        $this->load->view('templates/footer');
    }

    public function vote($id)
    {

        $dataid = $this->db->get_where('headmaster', ['id' => $id])->row_array();
        $user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $datavote = $this->db->get_where('vote', ['user_id' => $user['id']])->row_array();

        if (!$datavote) {

            $vote = [
                'id' => 0,
                'user_id' => $user['id'],
                'vote_to_id' => $id
            ];
            $this->db->insert('vote', $vote);
            $this->db->update('headmaster', ['count' => $dataid['count'] + 1], ['id' => $id]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Voted!</div>');
            redirect('voting');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">You already voting!</div>');
            redirect('voting');
        }
    }
}
