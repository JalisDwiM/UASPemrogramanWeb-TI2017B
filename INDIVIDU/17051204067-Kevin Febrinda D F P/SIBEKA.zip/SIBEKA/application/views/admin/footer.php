<!-- /**
 * @Author: Moch Faizal Ansyori
 * @Date:   2017-06-12 10:14:24
 * @Last Modified by:   Moch Faizal Ansyori
 * @Last Modified time: 2017-06-12 10:14:33
 */
 -->

<div id="footer">
       <?php echo date('Y'); ?> &copy; MicroDevelopper
</div>