<!-- /**
 * @Author: Moch Faizal Ansyori
 * @Date:   2017-06-12 10:10:54
 * @Last Modified by:   Moch Faizal Ansyori
 * @Last Modified time: 2017-06-12 10:11:04
 */
 -->

<!-- BEGIN PAGE HEADER-->   
<div class="row-fluid">
   <div class="span12">
      <!-- BEGIN PAGE TITLE & BREADCRUMB-->
       <h3 class="page-title">
         <?php echo $cumb_up; ?>
       </h3>
       <?php echo $this->breadcrumb->output();  ?>
       <!-- END PAGE TITLE & BREADCRUMB-->
   </div>
</div>
<!-- END PAGE HEADER-->