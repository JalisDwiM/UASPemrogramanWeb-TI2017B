<!--
COPYRIGHT : M. Arief Rahman I.P
CREATED : 00.35 27/05/2019
NIM : 17051204047
-->
<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbName = "crud";
mysql_connect($host, $user, $pass);
mysql_select_db($dbName)
or die ("Connect Failed !! : ".mysql_error());
?>